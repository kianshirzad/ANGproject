import { DataService } from "./data.service";

export class Shared {
    constructor(public data: DataService) { }
}
