import { Component } from '@angular/core';

@Component({
  selector: 'app-blog3',
  standalone: true,
  imports: [],
  templateUrl: './blog3.component.html',
  styleUrl: './blog3.component.scss'
})
export class Blog3Component {

}
