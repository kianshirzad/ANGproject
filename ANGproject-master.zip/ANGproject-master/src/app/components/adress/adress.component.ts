import { Component } from '@angular/core';

@Component({
  selector: 'app-adress',
  standalone: true,
  imports: [],
  templateUrl: './adress.component.html',
  styleUrl: './adress.component.scss'
})
export class AdressComponent {

}
