import { Component } from '@angular/core';

@Component({
  selector: 'app-producta-listing',
  templateUrl: './producta-listing.component.html',
  styleUrl: './producta-listing.component.scss'
})
export class ProductaListingComponent {

}
