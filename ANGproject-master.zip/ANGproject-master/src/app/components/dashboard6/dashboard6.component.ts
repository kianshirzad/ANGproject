import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard6',
  standalone: true,
  imports: [],
  templateUrl: './dashboard6.component.html',
  styleUrl: './dashboard6.component.scss'
})
export class Dashboard6Component {

}
